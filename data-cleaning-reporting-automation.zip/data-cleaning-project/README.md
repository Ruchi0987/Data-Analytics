# Data Cleaning & Reporting Automation

An end-to-end Python pipeline that takes a messy, real-world-style retail sales
dataset and automatically cleans it, audits data quality before/after, and
generates a visual summary report — with zero manual steps.

## Problem

Raw exports from CRMs, POS systems, and web forms are rarely analysis-ready.
This project simulates that reality with a synthetic dataset containing:

- **728 missing values** across 7 columns
- **61 duplicate rows** (exact re-entries)
- **27 inconsistent category label variants** (`electronics`, `ELECTRONICS `, `Electronics` → same thing)
- **Inconsistent region names** (`Nort`, `SOUTH`, `west` → same thing)
- **Currency-formatted price strings** (`₹1,499.00` mixed with plain numbers)
- **5 different date formats** in a single column
- **Invalid/malformed emails**
- **Negative and zero quantities** (data-entry errors)
- **Extreme price outliers**

## What the Pipeline Does

1. **Audits** the raw data — missing value counts, duplicate rows, dtype issues
2. **Cleans** it — standardizes text, validates emails, parses mixed date formats,
   strips currency symbols, caps outliers, removes duplicates, imputes missing values
3. **Re-audits** the cleaned data to prove the improvement
4. **Saves** a clean, analysis-ready CSV
5. **Generates** 6 visual summary charts + a Markdown report automatically

Every step is logged to `data/pipeline.log` for auditability — this is built to
be scheduled (cron, Task Scheduler, Airflow) and run unattended.

## Project Structure

```
data-cleaning-project/
├── data/
│   ├── raw/retail_sales_raw.csv          # messy synthetic input (2,090 rows)
│   ├── cleaned/retail_sales_cleaned.csv  # clean output (1,963 rows)
│   └── pipeline.log                      # run log
├── scripts/
│   ├── generate_dataset.py               # generates the messy sample data
│   ├── cleaning_utils.py                 # reusable cleaning functions
│   └── pipeline.py                       # main automation pipeline (CLI)
├── notebooks/
│   └── data_cleaning_walkthrough.ipynb   # step-by-step interactive version
├── reports/
│   ├── cleaning_report.md                # auto-generated summary report
│   └── 01–06_*.png                       # auto-generated charts
└── requirements.txt
```

## How to Run

```bash
pip install -r requirements.txt

# Regenerate a fresh messy sample dataset (optional — one is already included)
python scripts/generate_dataset.py

# Run the full cleaning + reporting pipeline
python scripts/pipeline.py --input data/raw/retail_sales_raw.csv --output data/cleaned/retail_sales_cleaned.csv
```

To run it against **your own dataset**, point `--input` at any CSV with similar
columns, or adapt the column names in `pipeline.py` / `cleaning_utils.py` — the
functions (`clean_price_column`, `parse_mixed_dates`, `validate_email`,
`standardize_text_column`, `cap_outliers_iqr`) are dataset-agnostic and reusable.

## Results

| Metric | Before | After |
|---|---|---|
| Rows | 2,090 | 1,963 |
| Duplicate rows | 61 | 0 |
| Missing cells | 728 | 248 (Email only — left blank rather than fabricated) |
| Category label variants | 27 | 6 (canonical) |
| Date formats | 5 mixed | 1 consistent |

See [`reports/cleaning_report.md`](reports/cleaning_report.md) for the full
auto-generated report with charts.

## Tech Stack

- **pandas / numpy** — data manipulation
- **matplotlib / seaborn** — automated visual reporting
- **Python `logging`** — audit trail for every pipeline run
- **argparse** — CLI automation, cron/scheduler-ready

## Design Decisions

- **No silent guessing:** invalid emails and unparseable dates are nulled/dropped
  rather than fabricated. Missing categoricals become an explicit `"Unknown"` label
  (visible in reporting) rather than being dropped or silently imputed.
- **Median imputation** for numeric gaps — robust to the outliers already present
  in raw data, unlike mean imputation.
- **IQR outlier capping** (wide factor) — catches genuine data-entry errors
  (e.g. a price 20x normal) without flattening real variance.
- **Every transformation is logged**, not just the final result — this is what
  makes the pipeline safe to run unattended and auditable after the fact.
