# Resume Bullets & Interview Prep

## Resume Bullets (pick 2–3 based on the role)

- Built an end-to-end Python data cleaning and reporting automation pipeline
  that resolved 728 missing values, removed 61 duplicate records, and
  standardized 27 inconsistent categorical label variants across a 2,090-row
  retail dataset, improving data completeness from ~65% to ~99%.
- Designed reusable, dataset-agnostic cleaning functions (mixed-format date
  parsing, currency normalization, email validation, IQR-based outlier
  capping) packaged as a CLI tool for unattended/scheduled execution.
- Automated generation of visual data-quality and business summary reports
  (6 charts + Markdown report) from raw CSV input, cutting manual reporting
  time from hours to seconds.
- Implemented full audit logging across the pipeline (before/after data
  quality metrics) to ensure transformations are transparent and reproducible.

## Likely Interview Questions & How to Answer

**Q: Walk me through your data cleaning process.**
A: Start with an audit (missing values, duplicates, dtype issues) before touching
anything — you need a baseline to prove improvement. Then clean column by column
with a documented rule per issue type (not guesswork): text standardization via
a lookup table, currency stripping + numeric conversion, mixed-date parsing,
email regex validation, IQR-based outlier capping, then duplicate removal, then
imputation as a last resort. Finish with a second audit to show before/after.

**Q: Why median imputation instead of mean?**
A: The raw data has genuine outliers (a few extreme prices). Mean is sensitive
to those; median isn't. For skewed real-world data, median is the safer default.

**Q: How did you handle missing categorical values — why not just drop those rows?**
A: Dropping rows discards other valid columns in that row and can bias the
dataset if missingness isn't random. I filled them with an explicit "Unknown"
label instead — it's visible in downstream reporting (you can see "X% Unknown
region") rather than silently vanishing, so a stakeholder can decide whether
that's acceptable.

**Q: How would you handle a dataset with millions of rows instead of a few thousand?**
A: The pandas-based approach would need to move to chunked processing or a tool
like Polars/Dask for parallelism, and the cleaning logic (which is vectorized
already via `.apply`/regex) would mostly transfer unchanged. I'd also move
logging/monitoring to something more robust than a flat log file, and add
schema validation (e.g. Great Expectations/Pandera) as a fail-fast layer before
cleaning even starts.

**Q: How is this "automated" and not just a script?**
A: It's parameterized via CLI args (any input/output path), it logs every step
for auditability, and it doesn't require manual intervention — it can be
triggered by cron, a scheduler, or a CI/CD pipeline and will produce a fresh
report from any new raw export.

**Q: What would you add with more time?**
A: Schema validation up front (catch a wrong column name before cleaning runs),
unit tests for each cleaning function, a config file for lookup dictionaries
(so category/region mappings aren't hardcoded), and an HTML/PDF export of the
report for non-technical stakeholders.

## Project Summary (for LinkedIn / portfolio site)

"Data Cleaning & Reporting Automation" — a Python pipeline that turns messy
raw CSV exports (missing values, duplicates, inconsistent formatting) into
clean, analysis-ready data and auto-generates a visual summary report. Built
with pandas, matplotlib/seaborn, and a logging-based audit trail; designed to
run unattended on a schedule. [GitHub link]
