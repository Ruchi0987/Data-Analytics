"""
pipeline.py
------------
End-to-end Data Cleaning & Reporting Automation pipeline.

Usage:
    python pipeline.py --input data/raw/retail_sales_raw.csv --output data/cleaned/retail_sales_cleaned.csv

What it does:
    1. Loads raw data
    2. Runs a BEFORE data-quality audit (missing values, duplicates, dtype issues)
    3. Cleans the data (missing values, duplicates, inconsistent formatting)
    4. Runs an AFTER data-quality audit
    5. Saves the cleaned dataset
    6. Generates a visual summary report (PNG charts) + a Markdown/HTML report
    7. Logs every step to a timestamped log file (data/pipeline.log) for auditability

Designed to be automation-friendly: can be scheduled via cron / Task Scheduler /
Airflow, or wrapped in a CI job, without any manual steps.
"""

import argparse
import logging
import sys
from datetime import datetime
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import pandas as pd
import seaborn as sns

sys.path.append(str(Path(__file__).parent))
from cleaning_utils import (
    standardize_text_column, clean_customer_name, clean_price_column,
    parse_mixed_dates, validate_email, flag_quantity_issues,
    cap_outliers_iqr, missing_value_report, CATEGORY_LOOKUP, REGION_LOOKUP,
    VALID_CATEGORIES, VALID_REGIONS,
)

PROJECT_ROOT = Path(__file__).parent.parent
LOG_PATH = PROJECT_ROOT / "data" / "pipeline.log"

sns.set_theme(style="whitegrid")
PALETTE = ["#2E5EAA", "#5FA8D3", "#F2A541", "#E4572E", "#76B041", "#8E6C88"]


def setup_logging():
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.FileHandler(LOG_PATH), logging.StreamHandler(sys.stdout)],
    )
    return logging.getLogger("pipeline")


def audit_data(df: pd.DataFrame, label: str, log: logging.Logger) -> dict:
    audit = {
        "label": label,
        "rows": len(df),
        "columns": len(df.columns),
        "duplicate_rows": int(df.duplicated().sum()),
        "missing_report": missing_value_report(df),
        "total_missing_cells": int(df.isna().sum().sum()),
    }
    log.info(f"[{label}] rows={audit['rows']} duplicates={audit['duplicate_rows']} "
              f"missing_cells={audit['total_missing_cells']}")
    return audit


def clean_dataset(df: pd.DataFrame, log: logging.Logger) -> pd.DataFrame:
    df = df.copy()

    log.info("Standardizing CustomerName (trim whitespace, title case)...")
    df["CustomerName"] = clean_customer_name(df["CustomerName"])

    log.info("Validating email addresses (invalid formats -> null)...")
    df["Email"] = validate_email(df["Email"])

    log.info("Standardizing ProductCategory labels...")
    df["ProductCategory"] = standardize_text_column(df["ProductCategory"], CATEGORY_LOOKUP, VALID_CATEGORIES)

    log.info("Standardizing Region labels...")
    df["Region"] = standardize_text_column(df["Region"], REGION_LOOKUP, VALID_REGIONS)

    log.info("Cleaning UnitPrice (stripping currency symbols/commas)...")
    df["UnitPrice"] = clean_price_column(df["UnitPrice"])
    log.info("Capping extreme UnitPrice outliers (IQR method)...")
    df["UnitPrice"] = cap_outliers_iqr(df["UnitPrice"])

    log.info("Flagging invalid Quantity values (<=0 -> null)...")
    df["Quantity"] = flag_quantity_issues(df["Quantity"])

    log.info("Parsing mixed-format OrderDate strings into datetime...")
    df["OrderDate"] = parse_mixed_dates(df["OrderDate"])

    log.info("Standardizing PaymentMethod (trim/title case, fill unknown)...")
    df["PaymentMethod"] = df["PaymentMethod"].astype(str).str.strip().replace("nan", None)
    df["PaymentMethod"] = df["PaymentMethod"].fillna("Unknown")

    before = len(df)
    log.info("Dropping exact duplicate rows...")
    df = df.drop_duplicates()
    log.info(f"Removed {before - len(df)} exact duplicate rows.")

    before = len(df)
    log.info("Dropping near-duplicate rows (same OrderID kept once)...")
    df = df.drop_duplicates(subset=["OrderID"], keep="first")
    log.info(f"Removed {before - len(df)} near-duplicate rows (repeat OrderIDs).")

    # Impute remaining missing numeric values with median (documented, not silent)
    for col in ["Quantity", "UnitPrice"]:
        n_missing = df[col].isna().sum()
        if n_missing:
            median_val = df[col].median()
            df[col] = df[col].fillna(median_val)
            log.info(f"Imputed {n_missing} missing '{col}' values with median ({median_val:.2f}).")

    # Categorical missing -> explicit 'Unknown' rather than dropped rows
    for col in ["CustomerName", "ProductCategory", "Region"]:
        n_missing = df[col].isna().sum()
        if n_missing:
            df[col] = df[col].fillna("Unknown")
            log.info(f"Filled {n_missing} missing '{col}' values with 'Unknown'.")

    # Rows with unrecoverable OrderDate are dropped (can't report by date meaningfully)
    before = len(df)
    df = df.dropna(subset=["OrderDate"])
    log.info(f"Dropped {before - len(df)} rows with unparseable OrderDate.")

    df["Revenue"] = (df["Quantity"] * df["UnitPrice"]).round(2)
    df = df.sort_values("OrderDate").reset_index(drop=True)

    return df


def generate_visual_report(df_before: pd.DataFrame, df_after: pd.DataFrame,
                            audit_before: dict, audit_after: dict,
                            reports_dir: Path, log: logging.Logger):
    reports_dir.mkdir(parents=True, exist_ok=True)

    # 1. Missing values before vs after
    fig, ax = plt.subplots(figsize=(9, 5))
    miss_before = audit_before["missing_report"]["missing_count"]
    cols = miss_before.index.tolist()
    after_counts = [df_after.isna().sum().get(c, 0) if c in df_after.columns else 0 for c in cols]
    x = range(len(cols))
    ax.bar([i - 0.2 for i in x], miss_before.values, width=0.4, label="Before Cleaning", color=PALETTE[3])
    ax.bar([i + 0.2 for i in x], after_counts, width=0.4, label="After Cleaning", color=PALETTE[4])
    ax.set_xticks(list(x))
    ax.set_xticklabels(cols, rotation=30, ha="right")
    ax.set_ylabel("Missing Value Count")
    ax.set_title("Missing Values: Before vs After Cleaning")
    ax.legend()
    fig.tight_layout()
    fig.savefig(reports_dir / "01_missing_values_before_after.png", dpi=150)
    plt.close(fig)

    # 2. Duplicate rows removed
    fig, ax = plt.subplots(figsize=(5, 5))
    values = [audit_before["duplicate_rows"] + (audit_before["rows"] - audit_after["rows"]) -
              (audit_before["duplicate_rows"]), audit_after["duplicate_rows"]]
    labels = ["Rows Removed\n(duplicates)", "Remaining\nDuplicates"]
    removed = audit_before["rows"] - len(df_after)
    ax.bar(["Original Rows", "Rows Removed", "Final Rows"],
           [audit_before["rows"], removed, len(df_after)],
           color=[PALETTE[1], PALETTE[3], PALETTE[4]])
    ax.set_title("Row Count: Raw vs Cleaned")
    ax.set_ylabel("Row Count")
    for i, v in enumerate([audit_before["rows"], removed, len(df_after)]):
        ax.text(i, v, str(v), ha="center", va="bottom")
    fig.tight_layout()
    fig.savefig(reports_dir / "02_row_count_summary.png", dpi=150)
    plt.close(fig)

    # 3. Revenue by category
    fig, ax = plt.subplots(figsize=(8, 5))
    rev_by_cat = df_after.groupby("ProductCategory")["Revenue"].sum().sort_values(ascending=False)
    ax.bar(rev_by_cat.index, rev_by_cat.values, color=PALETTE)
    ax.set_title("Total Revenue by Product Category (Cleaned Data)")
    ax.set_ylabel("Revenue (₹)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:,.0f}"))
    plt.xticks(rotation=20, ha="right")
    fig.tight_layout()
    fig.savefig(reports_dir / "03_revenue_by_category.png", dpi=150)
    plt.close(fig)

    # 4. Monthly revenue trend
    fig, ax = plt.subplots(figsize=(9, 5))
    monthly = df_after.set_index("OrderDate").resample("ME")["Revenue"].sum()
    ax.plot(monthly.index, monthly.values, marker="o", color=PALETTE[0], linewidth=2)
    ax.set_title("Monthly Revenue Trend (Cleaned Data)")
    ax.set_ylabel("Revenue (₹)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:,.0f}"))
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(reports_dir / "04_monthly_revenue_trend.png", dpi=150)
    plt.close(fig)

    # 5. Region distribution
    fig, ax = plt.subplots(figsize=(6, 6))
    region_counts = df_after["Region"].value_counts()
    ax.pie(region_counts.values, labels=region_counts.index, autopct="%1.1f%%",
           colors=PALETTE, startangle=90)
    ax.set_title("Orders by Region (Cleaned Data)")
    fig.tight_layout()
    fig.savefig(reports_dir / "05_orders_by_region.png", dpi=150)
    plt.close(fig)

    # 6. Payment method breakdown
    fig, ax = plt.subplots(figsize=(8, 5))
    pay_counts = df_after["PaymentMethod"].value_counts()
    ax.barh(pay_counts.index, pay_counts.values, color=PALETTE)
    ax.set_title("Orders by Payment Method (Cleaned Data)")
    ax.set_xlabel("Order Count")
    fig.tight_layout()
    fig.savefig(reports_dir / "06_payment_method_breakdown.png", dpi=150)
    plt.close(fig)

    log.info(f"Saved 6 visual summary charts to {reports_dir}")


def generate_markdown_report(audit_before: dict, audit_after: dict,
                              df_after: pd.DataFrame, reports_dir: Path,
                              run_timestamp: str) -> Path:
    total_revenue = df_after["Revenue"].sum()
    top_category = df_after.groupby("ProductCategory")["Revenue"].sum().idxmax()
    top_region = df_after["Region"].value_counts().idxmax()
    rows_removed = audit_before["rows"] - audit_after["rows"]

    md = f"""# Data Cleaning & Reporting — Automated Summary

**Run timestamp:** {run_timestamp}

## 1. Data Quality: Before vs After

| Metric | Before Cleaning | After Cleaning |
|---|---|---|
| Rows | {audit_before['rows']:,} | {audit_after['rows']:,} |
| Duplicate rows | {audit_before['duplicate_rows']:,} | {audit_after['duplicate_rows']:,} |
| Total missing cells | {audit_before['total_missing_cells']:,} | {df_after.isna().sum().sum():,} |
| Rows removed (duplicates/unrecoverable) | — | {rows_removed:,} |

### Missing values by column (before cleaning)

{audit_before['missing_report'].to_markdown()}

## 2. Cleaning Actions Applied
- Standardized inconsistent category labels (e.g. `electronics`, `ELECTRONICS ` → `Electronics`)
- Standardized inconsistent region labels (e.g. `Nort`, `SOUTH` → `North`, `South`)
- Trimmed whitespace and normalized casing in customer names
- Validated email addresses; malformed emails set to null rather than kept
- Stripped currency symbols/commas from price fields and converted to numeric
- Capped extreme price outliers using the IQR method
- Flagged and nulled invalid (zero/negative) quantities
- Parsed 5 different date formats into a single consistent datetime column
- Removed exact duplicate rows and repeat OrderIDs
- Imputed remaining missing numeric values with column median
- Filled remaining missing categorical values with `"Unknown"` (kept visible, not dropped)
- Dropped rows with unrecoverable order dates

## 3. Business Summary (Cleaned Data)
- **Total revenue:** ₹{total_revenue:,.2f}
- **Top-performing category:** {top_category}
- **Highest order volume region:** {top_region}
- **Date range covered:** {df_after['OrderDate'].min().date()} to {df_after['OrderDate'].max().date()}

## 4. Visual Summaries
![Missing values before/after](01_missing_values_before_after.png)
![Row count summary](02_row_count_summary.png)
![Revenue by category](03_revenue_by_category.png)
![Monthly revenue trend](04_monthly_revenue_trend.png)
![Orders by region](05_orders_by_region.png)
![Payment method breakdown](06_payment_method_breakdown.png)

---
*Generated automatically by `pipeline.py`. Re-run against any new raw export to refresh this report.*
"""
    out_path = reports_dir / "cleaning_report.md"
    out_path.write_text(md)
    return out_path


def main():
    parser = argparse.ArgumentParser(description="Data Cleaning & Reporting Automation Pipeline")
    parser.add_argument("--input", default=str(PROJECT_ROOT / "data" / "raw" / "retail_sales_raw.csv"))
    parser.add_argument("--output", default=str(PROJECT_ROOT / "data" / "cleaned" / "retail_sales_cleaned.csv"))
    parser.add_argument("--reports-dir", default=str(PROJECT_ROOT / "reports"))
    args = parser.parse_args()

    log = setup_logging()
    run_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log.info("=" * 70)
    log.info(f"Pipeline run started: {run_ts}")

    log.info(f"Loading raw data from {args.input}")
    df_raw = pd.read_csv(args.input)

    audit_before = audit_data(df_raw, "BEFORE", log)

    df_clean = clean_dataset(df_raw, log)

    audit_after = audit_data(df_clean, "AFTER", log)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df_clean.to_csv(output_path, index=False)
    log.info(f"Cleaned dataset saved to {output_path}")

    reports_dir = Path(args.reports_dir)
    generate_visual_report(df_raw, df_clean, audit_before, audit_after, reports_dir, log)
    report_path = generate_markdown_report(audit_before, audit_after, df_clean, reports_dir, run_ts)
    log.info(f"Markdown report saved to {report_path}")

    log.info("Pipeline run completed successfully.")
    log.info("=" * 70)


if __name__ == "__main__":
    main()
