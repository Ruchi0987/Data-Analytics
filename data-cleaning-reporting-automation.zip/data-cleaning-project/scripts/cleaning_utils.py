"""
cleaning_utils.py
------------------
Reusable, documented data-cleaning functions used by the automation
pipeline (pipeline.py). Each function is intentionally self-contained
so it can be reused across different datasets/projects.
"""

import re
import numpy as np
import pandas as pd

VALID_CATEGORIES = ["Electronics", "Apparel", "Home & Kitchen", "Books", "Beauty", "Sports"]
VALID_REGIONS = ["North", "South", "East", "West"]

CATEGORY_LOOKUP = {
    "electronics": "Electronics",
    "apparel": "Apparel", "aparel": "Apparel",
    "home & kitchen": "Home & Kitchen", "home and kitchen": "Home & Kitchen",
    "books": "Books",
    "beauty": "Beauty", "beuty": "Beauty",
    "sports": "Sports", "sport": "Sports",
}

REGION_LOOKUP = {
    "north": "North", "nort": "North",
    "south": "South",
    "east": "East",
    "west": "West", "wast": "West",
}

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")


def standardize_text_column(series: pd.Series, lookup: dict, valid_values: list) -> pd.Series:
    """
    Trims whitespace, normalizes case, and maps known variants (typos/case)
    to a single canonical value using a lookup dict. Anything unmatched is
    left as NaN-safe title case rather than silently dropped, so it stays
    visible in the data-quality report.
    """
    cleaned = series.astype(str).str.strip()
    cleaned = cleaned.replace("nan", np.nan)

    def map_value(v):
        if pd.isna(v):
            return v
        key = v.strip().lower()
        return lookup.get(key, v.strip())

    return cleaned.apply(map_value)


def clean_customer_name(series: pd.Series) -> pd.Series:
    """Trim whitespace/collapse internal double-spaces, title-case names."""
    cleaned = series.astype(str).str.strip()
    cleaned = cleaned.replace("nan", np.nan)
    cleaned = cleaned.str.replace(r"\s+", " ", regex=True)
    return cleaned.str.title()


def clean_price_column(series: pd.Series) -> pd.Series:
    """
    Strips currency symbols (₹, $) and thousands separators, converts to
    float. Non-numeric/garbage values become NaN (flagged, not guessed).
    """
    def parse(v):
        if pd.isna(v):
            return np.nan
        s = str(v)
        s = re.sub(r"[₹$,]", "", s).strip()
        try:
            return float(s)
        except ValueError:
            return np.nan
    return series.apply(parse)


def parse_mixed_dates(series: pd.Series) -> pd.Series:
    """
    Parses a column containing multiple date string formats
    (YYYY-MM-DD, DD/MM/YYYY, DD-MM-YYYY, MM/DD/YYYY, 'DD Mon YYYY')
    into a single consistent datetime64 dtype.
    """
    known_formats = ["%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y", "%d %b %Y"]

    def parse_one(v):
        if pd.isna(v):
            return pd.NaT
        for fmt in known_formats:
            try:
                return pd.to_datetime(v, format=fmt)
            except (ValueError, TypeError):
                continue
        # last resort: let pandas guess
        return pd.to_datetime(v, errors="coerce", dayfirst=True)

    return series.apply(parse_one)


def validate_email(series: pd.Series) -> pd.Series:
    """Returns the email if it matches a valid pattern, else NaN."""
    def check(v):
        if pd.isna(v) or str(v).strip() == "":
            return np.nan
        v = str(v).strip()
        return v if EMAIL_REGEX.match(v) else np.nan
    return series.apply(check)


def flag_quantity_issues(series: pd.Series) -> pd.Series:
    """Negative or zero quantities are data-entry errors -> set to NaN."""
    return series.apply(lambda x: np.nan if pd.notna(x) and x <= 0 else x)


def cap_outliers_iqr(series: pd.Series, factor: float = 3.0) -> pd.Series:
    """
    Caps extreme outliers using the IQR method (very wide factor=3.0 so
    only genuine data-entry errors, not normal variance, get capped).
    """
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    upper = q3 + factor * iqr
    lower = max(0, q1 - factor * iqr)
    return series.clip(lower=lower, upper=upper)


def missing_value_report(df: pd.DataFrame) -> pd.DataFrame:
    """Returns a tidy summary of missing values per column."""
    missing = df.isna().sum()
    pct = (missing / len(df) * 100).round(2)
    report = pd.DataFrame({"missing_count": missing, "missing_pct": pct})
    return report[report["missing_count"] > 0].sort_values("missing_count", ascending=False)
