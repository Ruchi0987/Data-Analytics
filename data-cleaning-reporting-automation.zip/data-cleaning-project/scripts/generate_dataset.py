"""
generate_dataset.py
--------------------
Generates a realistic, MESSY retail sales dataset to simulate real-world
data quality issues. This is the raw input for the cleaning pipeline.

Issues deliberately injected:
- Missing values (various columns, various rates)
- Exact duplicate rows
- Near-duplicate rows (same order, re-entered with typos)
- Inconsistent text casing / whitespace
- Inconsistent category labels ("Electronics", "electronics ", "ELECTRONICS")
- Inconsistent date formats
- Currency symbols / commas in numeric fields
- Invalid emails
- Negative / zero quantities (data entry errors)
- Outlier prices
- Inconsistent country / region naming
"""

import numpy as np
import pandas as pd
import random
from datetime import datetime, timedelta

random.seed(42)
np.random.seed(42)

N = 2000

first_names = ["Aarav", "Vivaan", "Aditya", "Priya", "Ananya", "Diya", "Ishaan",
               "Kabir", "Riya", "Meera", "Rohan", "Sanya", "Karan", "Neha",
               "Arjun", "Simran", "Yash", "Tanvi", "Aryan", "Pooja"]
last_names = ["Sharma", "Verma", "Gupta", "Singh", "Reddy", "Kumar", "Iyer",
              "Nair", "Chatterjee", "Mehta", "Joshi", "Malhotra", "Kapoor", "Rao"]

categories_clean = ["Electronics", "Apparel", "Home & Kitchen", "Books", "Beauty", "Sports"]
category_variants = {
    "Electronics": ["Electronics", "electronics", "ELECTRONICS", " Electronics", "Electronics "],
    "Apparel": ["Apparel", "apparel", "APPAREL", "Aparel", " Apparel"],
    "Home & Kitchen": ["Home & Kitchen", "home & kitchen", "Home and Kitchen", "HOME & KITCHEN"],
    "Books": ["Books", "books", "BOOKS", " Books"],
    "Beauty": ["Beauty", "beauty", "BEAUTY", "Beuty"],
    "Sports": ["Sports", "sports", "SPORTS", "Sport"],
}

products = {
    "Electronics": ["Wireless Earbuds", "Bluetooth Speaker", "Smartwatch", "Power Bank", "USB-C Cable"],
    "Apparel": ["Cotton T-Shirt", "Denim Jacket", "Running Shoes", "Formal Shirt", "Hoodie"],
    "Home & Kitchen": ["Non-Stick Pan", "Air Fryer", "Mixer Grinder", "Bed Sheet Set", "LED Lamp"],
    "Books": ["Fiction Novel", "Self-Help Book", "Cookbook", "Biography", "Comic Book"],
    "Beauty": ["Face Serum", "Lipstick", "Shampoo", "Sunscreen", "Perfume"],
    "Sports": ["Yoga Mat", "Dumbbell Set", "Cricket Bat", "Football", "Cycling Helmet"],
}

regions_clean = ["North", "South", "East", "West"]
region_variants = {
    "North": ["North", "north", "NORTH", "Nort"],
    "South": ["South", "south", "SOUTH"],
    "East": ["East", "east", "EAST"],
    "West": ["West", "west", "WEST", "Wast"],
}

payment_methods = ["Credit Card", "Debit Card", "UPI", "Net Banking", "Cash on Delivery", None]

date_formats = ["%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y", "%d %b %Y"]

def random_date():
    start = datetime(2023, 1, 1)
    end = datetime(2024, 12, 31)
    delta = end - start
    d = start + timedelta(days=random.randint(0, delta.days))
    fmt = random.choice(date_formats)
    return d.strftime(fmt)

def random_email(name, valid=True):
    domain = random.choice(["gmail.com", "yahoo.com", "outlook.com", "rediffmail.com"])
    handle = name.lower().replace(" ", ".")
    if valid:
        return f"{handle}{random.randint(1,999)}@{domain}"
    else:
        # broken email formats
        bad_forms = [
            f"{handle}{random.randint(1,999)}@{domain.split('.')[0]}",  # missing .com
            f"{handle}{random.randint(1,999)}{domain}",  # missing @
            f"{handle} @{domain}",  # stray space
            "",
        ]
        return random.choice(bad_forms)

rows = []
for i in range(1, N + 1):
    cat_clean = random.choice(categories_clean)
    cat = random.choice(category_variants[cat_clean])
    product = random.choice(products[cat_clean])
    region_clean = random.choice(regions_clean)
    region = random.choice(region_variants[region_clean])

    fname = random.choice(first_names)
    lname = random.choice(last_names)
    # inconsistent casing / whitespace in names
    name_variant = random.choice([
        f"{fname} {lname}",
        f"{fname.upper()} {lname.upper()}",
        f" {fname} {lname} ",
        f"{fname.lower()} {lname.lower()}",
    ])

    qty = np.random.randint(1, 10)
    # inject bad quantities
    if random.random() < 0.02:
        qty = -abs(qty)  # negative
    if random.random() < 0.015:
        qty = 0

    base_price = {
        "Electronics": 1500, "Apparel": 800, "Home & Kitchen": 1200,
        "Books": 300, "Beauty": 500, "Sports": 900
    }[cat_clean]
    price = round(np.random.normal(base_price, base_price * 0.25), 2)
    price = max(price, 50)
    # inject outliers
    if random.random() < 0.005:
        price *= 20
    # inject currency-symbol / comma formatted strings occasionally
    if random.random() < 0.15:
        price_str = f"₹{price:,.2f}"
    else:
        price_str = price

    email_valid = random.random() > 0.08
    email = random_email(fname + lname, valid=email_valid) if random.random() > 0.05 else None

    row = {
        "OrderID": f"ORD{i:05d}",
        "CustomerName": name_variant if random.random() > 0.03 else None,
        "Email": email,
        "ProductCategory": cat if random.random() > 0.02 else None,
        "Product": product,
        "Quantity": qty if random.random() > 0.01 else None,
        "UnitPrice": price_str,
        "OrderDate": random_date() if random.random() > 0.02 else None,
        "Region": region if random.random() > 0.02 else None,
        "PaymentMethod": random.choice(payment_methods),
    }
    rows.append(row)

df = pd.DataFrame(rows)

# Inject exact duplicate rows (~3%)
dupe_idx = np.random.choice(df.index, size=int(N * 0.03), replace=False)
df = pd.concat([df, df.loc[dupe_idx]], ignore_index=True)

# Inject near-duplicate rows (same OrderID re-entered with minor typo, ~1.5%)
near_dupe_idx = np.random.choice(df.index, size=int(N * 0.015), replace=False)
near_dupes = df.loc[near_dupe_idx].copy()
near_dupes["CustomerName"] = near_dupes["CustomerName"].astype(str) + " "
df = pd.concat([df, near_dupes], ignore_index=True)

# Shuffle rows
df = df.sample(frac=1, random_state=42).reset_index(drop=True)

out_path = "/home/claude/data-cleaning-project/data/raw/retail_sales_raw.csv"
df.to_csv(out_path, index=False)
print(f"Generated {len(df)} rows -> {out_path}")
print(df.head(10))
