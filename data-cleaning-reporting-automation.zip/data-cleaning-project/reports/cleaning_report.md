# Data Cleaning & Reporting — Automated Summary

**Run timestamp:** 2026-07-11 04:25:54

## 1. Data Quality: Before vs After

| Metric | Before Cleaning | After Cleaning |
|---|---|---|
| Rows | 2,090 | 1,963 |
| Duplicate rows | 61 | 0 |
| Total missing cells | 728 | 248 |
| Rows removed (duplicates/unrecoverable) | — | 127 |

### Missing values by column (before cleaning)

|                 |   missing_count |   missing_pct |
|:----------------|----------------:|--------------:|
| PaymentMethod   |             353 |         16.89 |
| Email           |             165 |          7.89 |
| Region          |              63 |          3.01 |
| CustomerName    |              56 |          2.68 |
| OrderDate       |              38 |          1.82 |
| ProductCategory |              34 |          1.63 |
| Quantity        |              19 |          0.91 |

## 2. Cleaning Actions Applied
- Standardized inconsistent category labels (e.g. `electronics`, `ELECTRONICS ` → `Electronics`)
- Standardized inconsistent region labels (e.g. `Nort`, `SOUTH` → `North`, `South`)
- Trimmed whitespace and normalized casing in customer names
- Validated email addresses; malformed emails set to null rather than kept
- Stripped currency symbols/commas from price fields and converted to numeric
- Capped extreme price outliers using the IQR method
- Flagged and nulled invalid (zero/negative) quantities
- Parsed 5 different date formats into a single consistent datetime column
- Removed exact duplicate rows and repeat OrderIDs
- Imputed remaining missing numeric values with column median
- Filled remaining missing categorical values with `"Unknown"` (kept visible, not dropped)
- Dropped rows with unrecoverable order dates

## 3. Business Summary (Cleaned Data)
- **Total revenue:** ₹8,579,715.51
- **Top-performing category:** Electronics
- **Highest order volume region:** West
- **Date range covered:** 2023-01-01 to 2024-12-30

## 4. Visual Summaries
![Missing values before/after](01_missing_values_before_after.png)
![Row count summary](02_row_count_summary.png)
![Revenue by category](03_revenue_by_category.png)
![Monthly revenue trend](04_monthly_revenue_trend.png)
![Orders by region](05_orders_by_region.png)
![Payment method breakdown](06_payment_method_breakdown.png)

---
*Generated automatically by `pipeline.py`. Re-run against any new raw export to refresh this report.*
