# Resume Bullets — Customer Segmentation Project

Pick 3–4 that best fit the role and space available. Formatted for ATS parsing (plain text, standard action verbs, quantified outcomes).

## For Data Science / Analytics roles

- Engineered a K-Means clustering pipeline in Python (scikit-learn, pandas) to segment 2,500 e-commerce customers into 5 behavioral personas using RFM and engagement features, achieving a silhouette score of 0.236 across 9 candidate values of k
- Applied StandardScaler, one-hot encoding, and PCA for dimensionality reduction to visualize high-dimensional customer behavior in 2D, validating cluster separation with silhouette and Davies-Bouldin metrics
- Identified a high-value customer segment representing 17% of the customer base that drove 61.3% of total revenue (3.6x value index), directly informing retention-budget prioritization
- Built and profiled 5 data-driven customer personas from demographic and behavioral data, translating unsupervised ML output into segment-specific business recommendations

## For Business/Product Analyst roles

- Conducted end-to-end customer segmentation analysis on a 2,500-record e-commerce dataset, uncovering that a top-tier segment (17% of customers) generated over 60% of revenue
- Built an interactive analytics dashboard (HTML/JS, Chart.js) visualizing customer segment performance, revenue concentration, and channel preferences for stakeholder review
- Authored a business insights report translating clustering output into segment-specific strategy recommendations across retention, win-back, and onboarding use cases
- Delivered actionable recommendations across 5 customer segments (loyalty, win-back, cross-sell, onboarding), grounded in behavioral data rather than intuition

## For Software/Full-Stack roles (if emphasizing the dashboard build)

- Designed and built a data-driven analytics dashboard from scratch (HTML, CSS, Chart.js) to visualize customer segmentation output, including KPI cards, radar comparisons, and stacked channel-mix charts
- Built a reproducible data pipeline from raw synthetic dataset generation through Jupyter-based analysis to a JSON-driven frontend dashboard

## Project summary line (for a "Projects" section header)

**Customer Segmentation Analytics — Python, scikit-learn, Pandas, Chart.js** | [GitHub link]
Unsupervised ML project segmenting e-commerce customers into actionable personas using K-Means clustering on RFM and behavioral features; includes an executed analysis notebook, interactive dashboard, and stakeholder-ready business report.
