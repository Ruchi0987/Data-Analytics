"""
Synthetic E-Commerce Customer Dataset Generator
------------------------------------------------
Generates a realistic customer base with demographic + behavioral features,
built from 5 latent archetypes (not labeled in the output) so that
clustering algorithms have genuine structure to recover.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 2500

# ---- Latent archetypes (hidden ground truth, used only to generate realistic data) ----
archetypes = [
    {  # 0: Premium Loyalists - high spend, frequent, low churn risk
        "name": "premium_loyalist", "weight": 0.16,
        "age": (34, 8), "income": (1450000, 300000), "membership_years": (4.2, 1.5),
        "purchase_freq": (28, 6), "aov": (3800, 800), "recency": (6, 4),
        "sessions": (22, 5), "discount_rate": (0.12, 0.06), "cart_abandon": (0.10, 0.05),
        "return_rate": (0.04, 0.02),
    },
    {  # 1: Bargain Hunters - frequent but low AOV, high discount usage
        "name": "bargain_hunter", "weight": 0.24,
        "age": (29, 7), "income": (550000, 150000), "membership_years": (2.1, 1.2),
        "purchase_freq": (19, 6), "aov": (850, 250), "recency": (10, 6),
        "sessions": (26, 7), "discount_rate": (0.68, 0.12), "cart_abandon": (0.35, 0.1),
        "return_rate": (0.09, 0.03),
    },
    {  # 2: New / Occasional Shoppers - low tenure, low frequency
        "name": "new_occasional", "weight": 0.22,
        "age": (26, 6), "income": (600000, 200000), "membership_years": (0.5, 0.3),
        "purchase_freq": (3, 2), "aov": (1400, 500), "recency": (35, 20),
        "sessions": (6, 3), "discount_rate": (0.30, 0.15), "cart_abandon": (0.45, 0.15),
        "return_rate": (0.07, 0.03),
    },
    {  # 3: At-Risk / Churn-Prone - used to buy, gone quiet
        "name": "at_risk", "weight": 0.20,
        "age": (38, 10), "income": (700000, 220000), "membership_years": (3.0, 1.4),
        "purchase_freq": (6, 3), "aov": (1600, 600), "recency": (95, 30),
        "sessions": (3, 2), "discount_rate": (0.25, 0.12), "cart_abandon": (0.55, 0.15),
        "return_rate": (0.12, 0.04),
    },
    {  # 4: Premium Browsers - high income, low frequency but high AOV, window shop
        "name": "premium_browser", "weight": 0.18,
        "age": (41, 9), "income": (1800000, 400000), "membership_years": (1.8, 1.0),
        "purchase_freq": (5, 2), "aov": (5200, 1200), "recency": (28, 15),
        "sessions": (14, 5), "discount_rate": (0.08, 0.05), "cart_abandon": (0.50, 0.12),
        "return_rate": (0.10, 0.04),
    },
]

weights = [a["weight"] for a in archetypes]
choice = np.random.choice(len(archetypes), size=N, p=weights)

def draw(param, n, low=None, high=None, round_int=False):
    mu, sigma = param
    vals = np.random.normal(mu, sigma, n)
    if low is not None:
        vals = np.clip(vals, low, None)
    if high is not None:
        vals = np.clip(vals, None, high)
    return np.round(vals).astype(int) if round_int else vals

rows = []
genders = ["Female", "Male", "Other"]
gender_p = [0.49, 0.48, 0.03]
cities = ["Tier 1", "Tier 2", "Tier 3"]
categories = ["Fashion & Apparel", "Electronics", "Home & Kitchen", "Beauty & Personal Care",
              "Books & Stationery", "Sports & Fitness", "Groceries"]
channels = ["Mobile App", "Website", "Both"]

for i in range(N):
    a = archetypes[choice[i]]
    age = int(np.clip(np.random.normal(*a["age"]), 18, 70))
    gender = np.random.choice(genders, p=gender_p)
    income = max(150000, np.random.normal(*a["income"]))
    membership_years = max(0.05, np.random.normal(*a["membership_years"]))
    purchase_freq = max(0, np.random.normal(*a["purchase_freq"]))
    aov = max(150, np.random.normal(*a["aov"]))
    recency = max(0, np.random.normal(*a["recency"]))
    sessions = max(0, np.random.normal(*a["sessions"]))
    discount_rate = np.clip(np.random.normal(*a["discount_rate"]), 0, 1)
    cart_abandon = np.clip(np.random.normal(*a["cart_abandon"]), 0, 1)
    return_rate = np.clip(np.random.normal(*a["return_rate"]), 0, 0.5)

    # city tier correlated loosely with income
    if income > 1200000:
        city = np.random.choice(cities, p=[0.7, 0.25, 0.05])
    elif income > 600000:
        city = np.random.choice(cities, p=[0.4, 0.45, 0.15])
    else:
        city = np.random.choice(cities, p=[0.2, 0.45, 0.35])

    total_spend = purchase_freq * aov
    preferred_category = np.random.choice(categories)
    channel = np.random.choice(channels, p=[0.55, 0.20, 0.25])
    satisfaction = np.clip(np.random.normal(4.2 - cart_abandon * 1.5 - return_rate * 3, 0.6), 1, 5)

    rows.append({
        "customer_id": f"CUST{i+1:05d}",
        "age": age,
        "gender": gender,
        "annual_income_inr": round(income, -3),
        "city_tier": city,
        "membership_years": round(membership_years, 2),
        "purchase_frequency_per_year": round(purchase_freq, 1),
        "avg_order_value_inr": round(aov, 2),
        "total_spend_inr": round(total_spend, 2),
        "days_since_last_purchase": round(recency, 1),
        "monthly_app_sessions": round(sessions, 1),
        "discount_usage_rate": round(discount_rate, 3),
        "cart_abandonment_rate": round(cart_abandon, 3),
        "product_return_rate": round(return_rate, 3),
        "preferred_category": preferred_category,
        "primary_channel": channel,
        "satisfaction_score": round(satisfaction, 2),
    })

df = pd.DataFrame(rows)

# introduce a small amount of realistic missingness (satisfaction survey not always filled)
missing_idx = np.random.choice(df.index, size=int(0.03 * N), replace=False)
df.loc[missing_idx, "satisfaction_score"] = np.nan

df = df.sample(frac=1, random_state=42).reset_index(drop=True)
df.to_csv("/home/claude/customer-segmentation/data/ecommerce_customers.csv", index=False)
print(df.shape)
print(df.head())
print(df.isna().sum())
