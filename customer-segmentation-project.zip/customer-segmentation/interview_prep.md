# Interview Prep — Customer Segmentation Project

## 30-second project summary (say this first, then let them dig in)

"I built an end-to-end customer segmentation pipeline on an e-commerce dataset — engineered RFM-style behavioral features, used K-Means to cluster 2,500 customers into 5 segments, validated the choice of k with the elbow method and silhouette score, then profiled each segment and translated the output into business recommendations. The most interesting finding was that revenue was extremely concentrated — the top segment was only 17% of customers but drove over 60% of revenue — which changes how you'd prioritize retention spend."

---

## Technical questions

**Q: Why K-Means and not another clustering algorithm (DBSCAN, hierarchical, GMM)?**
K-Means is a strong default for this kind of behavioral segmentation because the features are continuous, roughly convex clusters were expected, and the business needs a fixed, interpretable number of segments to build campaigns around. DBSCAN is great for arbitrary-shaped clusters and noise detection, but doesn't guarantee a fixed number of segments, which matters when a marketing team wants a stable set of personas. Hierarchical clustering doesn't scale as well and I didn't need the dendrogram structure. If I revisited this, I'd benchmark Gaussian Mixture Models too, since GMM gives soft cluster assignment (a customer can partially belong to two segments), which is arguably more realistic for behavior that isn't perfectly discrete.

**Q: How did you choose k=5?**
I ran K-Means for k=2 through 10 and looked at two things together: the elbow method (inertia/within-cluster sum of squares) and silhouette score. The elbow flattened noticeably around k=5, and silhouette score was locally strong there too. I also weighed business interpretability — more clusters might technically fit the data slightly better, but a marketing team can't operationalize 9 personas. That trade-off between statistical fit and business usability is a real decision, not just a technical one.

**Q: Your silhouette score (0.236) isn't very high — how do you explain that?**
A silhouette score around 0.2–0.3 is common in real behavioral/demographic data, where clusters overlap rather than being perfectly separated — customers exist on a spectrum, not in discrete boxes. I'd flag this honestly in any real analysis rather than overselling cluster quality, and use the Davies-Bouldin index and manual profile inspection as supporting evidence, not just one metric in isolation. The point isn't a "perfect" clustering — it's whether the resulting segments are stable and actionable.

**Q: Why scale the features before clustering?**
K-Means is distance-based (Euclidean distance to centroids), so features on larger numeric scales — like annual income in hundreds of thousands — would dominate the distance calculation and drown out features like discount usage rate, which lives between 0 and 1. StandardScaler puts everything on a comparable scale (zero mean, unit variance) so each feature contributes proportionally to what it actually explains, not its raw magnitude.

**Q: What's RFM and why use it here?**
RFM stands for Recency, Frequency, Monetary — a classic marketing framework for scoring customer value: how recently they bought, how often, and how much. I used it as the backbone of feature engineering because it's interpretable to a business audience, and extended it with engagement (app sessions) and risk signals (cart abandonment, return rate, discount reliance) to capture behavior RFM alone misses.

**Q: How would you validate that these clusters are meaningful, not just a mathematical artifact?**
Three ways: (1) statistical validation via silhouette/Davies-Bouldin scores across multiple k values, not just picking one number blind; (2) profile inspection — do the cluster centroids tell a coherent, distinct story when you look at the averages? In this case yes — one segment is clearly high-frequency/low-value, another is low-frequency/high-value, which is a believable real-world pattern; (3) in a production setting, I'd also want to A/B test segment-specific campaigns and see if the segments actually predict different response rates — that's the real test of whether a segmentation is useful, not just statistically distinct.

**Q: What would you do differently with real (not synthetic) data?**
Real data would have messier missingness, potential outliers (e.g. B2B accounts mixed into B2C data), and features that need more careful engineering — like defining "frequency" consistently across customers with very different tenure. I'd also want to check for leakage (e.g. total_spend correlating too strongly with a single dominant feature) and consider log-transforming skewed monetary features before scaling, since raw spend distributions are usually right-skewed.

**Q: How would you deploy or operationalize this?**
Push the `cluster`/`persona` label into the CRM or ad platform as a customer attribute, refresh the model on a schedule (I'd suggest quarterly, since behavior drifts), and track segment migration over time as a KPI — e.g., what % of "New & Occasional" customers graduate to "Loyalist" within 90 days. I'd also want a monitoring step: if silhouette score degrades significantly on a refresh, that's a signal customer behavior has shifted enough to reconsider k.

---

## Business / product questions

**Q: What was the most actionable insight?**
Revenue concentration. The top segment (17% of customers) drove 61% of revenue — a 3.6x value index. That's a very concrete, non-obvious number to bring to a stakeholder: it argues for shifting retention budget toward protecting that segment rather than spreading it evenly, and it reframes the "at-risk" segment as a reactivation opportunity rather than a lost cause, since some of them were previously high-value.

**Q: How would a marketing team actually use this?**
Each segment gets a different playbook: Premium Loyalists get VIP treatment, not discounts (discounting them would erode margin on customers who'd buy anyway). Bargain Hunters get bundle offers to lift basket size rather than deeper discounts. At-Risk gets win-back campaigns and a feedback survey to diagnose why they went quiet. New & Occasional gets onboarding nudges to get them to a second purchase, which is usually the highest-risk drop-off point.

**Q: How do you know this generalizes beyond the synthetic dataset?**
I don't claim it does directly — the dataset was synthetic, built from 5 designed archetypes with realistic parameter ranges so the clustering had genuine structure to recover. The value of the project is demonstrating the methodology end-to-end: feature engineering, model selection, validation, and business translation. On real company data, I'd expect the same pipeline to work, but the actual segment definitions and their relative value would need to be re-derived from that company's real behavior.

---

## If asked to whiteboard/extend live

- Be ready to sketch: raw data → feature engineering (RFM) → scaling → K-Means → validation (elbow/silhouette) → profiling → business translation.
- Be ready to explain the difference between supervised and unsupervised learning in one sentence, since interviewers often check this isn't just memorized.
- If asked "how would you predict which segment a *brand new* customer falls into," the answer is: you can't cluster a single new point meaningfully with K-Means alone — instead, train a classifier (e.g. logistic regression or a tree-based model) using the cluster labels as the target, so new customers get scored against the existing segment definitions in real time.
