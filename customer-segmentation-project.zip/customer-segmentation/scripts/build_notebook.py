import json

cells = []

def md(text):
    cells.append({"cell_type": "markdown", "metadata": {}, "source": text.splitlines(keepends=True)})

def code(text):
    cells.append({"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [], "source": text.splitlines(keepends=True)})

md("""# Customer Segmentation Analysis
### Behavioral & Demographic Clustering for an E-Commerce Platform

**Goal:** Segment customers using unsupervised machine learning (K-Means) based on demographic attributes and purchasing behavior, in order to enable targeted marketing, retention strategy, and personalized recommendations.

**Dataset:** 2,500 synthetic e-commerce customers with 16 demographic and behavioral features (purchase frequency, average order value, recency, discount usage, app engagement, satisfaction, etc.)

**Workflow:**
1. Data loading & quality checks
2. Exploratory Data Analysis (EDA)
3. Feature engineering (RFM-style behavioral metrics)
4. Preprocessing (encoding, scaling)
5. Determining optimal cluster count (Elbow method + Silhouette score)
6. K-Means clustering
7. Cluster profiling & business interpretation
8. Visualization of segments
9. Actionable business recommendations
""")

code("""import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, davies_bouldin_score

plt.rcParams['figure.dpi'] = 110
sns.set_style('whitegrid')
palette = ['#2E5266', '#6E8898', '#D97B29', '#9DAA6B', '#B24C4C']
sns.set_palette(palette)

pd.set_option('display.max_columns', 50)
%matplotlib inline
""")

md("## 1. Load & Inspect Data")

code("""df = pd.read_csv('../data/ecommerce_customers.csv')
print(f"Shape: {df.shape}")
df.head()
""")

code("""df.info()
""")

code("""df.describe(include='all').T
""")

md("""## 2. Data Quality Checks

`satisfaction_score` has a small amount of missing data (~3%), consistent with customers who never completed a post-purchase survey. We impute with the median to avoid dropping rows.
""")

code("""print("Missing values:\\n", df.isna().sum()[df.isna().sum() > 0])
print(f"\\nDuplicate customer_ids: {df['customer_id'].duplicated().sum()}")

df['satisfaction_score'] = df['satisfaction_score'].fillna(df['satisfaction_score'].median())
""")

md("""## 3. Exploratory Data Analysis

We look at the distribution of key behavioral and demographic variables before clustering, to understand the raw shape of the customer base.
""")

code("""fig, axes = plt.subplots(2, 3, figsize=(16, 9))
num_cols = ['age', 'annual_income_inr', 'purchase_frequency_per_year',
            'avg_order_value_inr', 'days_since_last_purchase', 'monthly_app_sessions']
titles = ['Age', 'Annual Income (INR)', 'Purchase Frequency (per yr)',
          'Avg Order Value (INR)', 'Days Since Last Purchase', 'Monthly App Sessions']

for ax, col, title in zip(axes.flat, num_cols, titles):
    sns.histplot(df[col], kde=True, ax=ax, color='#2E5266')
    ax.set_title(title)
    ax.set_xlabel('')

plt.tight_layout()
plt.savefig('../images/eda_distributions.png', bbox_inches='tight')
plt.show()
""")

code("""fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))

df['gender'].value_counts().plot(kind='bar', ax=axes[0], color='#2E5266')
axes[0].set_title('Gender Distribution')
axes[0].tick_params(axis='x', rotation=0)

df['city_tier'].value_counts().plot(kind='bar', ax=axes[1], color='#6E8898')
axes[1].set_title('City Tier Distribution')
axes[1].tick_params(axis='x', rotation=0)

df['primary_channel'].value_counts().plot(kind='bar', ax=axes[2], color='#D97B29')
axes[2].set_title('Primary Shopping Channel')
axes[2].tick_params(axis='x', rotation=0)

plt.tight_layout()
plt.savefig('../images/eda_categorical.png', bbox_inches='tight')
plt.show()
""")

code("""plt.figure(figsize=(9, 4))
df['preferred_category'].value_counts().plot(kind='barh', color='#9DAA6B')
plt.title('Preferred Product Category')
plt.xlabel('Number of Customers')
plt.tight_layout()
plt.savefig('../images/eda_category_pref.png', bbox_inches='tight')
plt.show()
""")

md("""### Correlation Check

Understanding which behavioral variables move together helps validate feature choices before clustering.
""")

code("""corr_cols = ['age', 'annual_income_inr', 'membership_years', 'purchase_frequency_per_year',
             'avg_order_value_inr', 'total_spend_inr', 'days_since_last_purchase',
             'monthly_app_sessions', 'discount_usage_rate', 'cart_abandonment_rate',
             'product_return_rate', 'satisfaction_score']

plt.figure(figsize=(10, 8))
sns.heatmap(df[corr_cols].corr(), annot=True, fmt='.2f', cmap='RdBu_r', center=0,
            linewidths=0.5, cbar_kws={'label': 'Correlation'})
plt.title('Correlation Matrix — Behavioral & Demographic Features')
plt.tight_layout()
plt.savefig('../images/correlation_heatmap.png', bbox_inches='tight')
plt.show()
""")

md("""## 4. Feature Engineering — RFM-Style Behavioral Metrics

We build a classic **Recency–Frequency–Monetary (RFM)** foundation, extended with engagement and loyalty-risk signals:

- **Recency** → `days_since_last_purchase` (lower = more recently active)
- **Frequency** → `purchase_frequency_per_year`
- **Monetary** → `total_spend_inr`, `avg_order_value_inr`
- **Engagement** → `monthly_app_sessions`
- **Value-seeking behavior** → `discount_usage_rate`
- **Friction/risk signals** → `cart_abandonment_rate`, `product_return_rate`

We also compute an **RFM score** (quintile-based) as an interpretable business metric alongside the ML clusters.
""")

code("""# Quintile-based RFM scoring (1 = worst, 5 = best) — standard marketing technique
df['R_score'] = pd.qcut(df['days_since_last_purchase'], 5, labels=[5,4,3,2,1]).astype(int)
df['F_score'] = pd.qcut(df['purchase_frequency_per_year'].rank(method='first'), 5, labels=[1,2,3,4,5]).astype(int)
df['M_score'] = pd.qcut(df['total_spend_inr'].rank(method='first'), 5, labels=[1,2,3,4,5]).astype(int)
df['RFM_score'] = df['R_score'] + df['F_score'] + df['M_score']

df[['customer_id', 'days_since_last_purchase', 'purchase_frequency_per_year',
    'total_spend_inr', 'R_score', 'F_score', 'M_score', 'RFM_score']].head()
""")

md("""## 5. Preprocessing for Clustering

K-Means is distance-based, so we:
1. Select the behavioral + demographic features that matter for segmentation
2. One-hot encode categorical variables (city tier, channel)
3. Standardize all features (zero mean, unit variance) so no single feature dominates due to scale (e.g. income in lakhs vs. rates between 0–1)
""")

code("""feature_cols_numeric = ['age', 'annual_income_inr', 'membership_years',
                         'purchase_frequency_per_year', 'avg_order_value_inr', 'total_spend_inr',
                         'days_since_last_purchase', 'monthly_app_sessions', 'discount_usage_rate',
                         'cart_abandonment_rate', 'product_return_rate', 'satisfaction_score']
feature_cols_categorical = ['city_tier', 'primary_channel']

X_numeric = df[feature_cols_numeric].copy()
X_categorical = pd.get_dummies(df[feature_cols_categorical], drop_first=True)

X = pd.concat([X_numeric, X_categorical], axis=1)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_scaled = pd.DataFrame(X_scaled, columns=X.columns)
X_scaled.head()
""")

md("""## 6. Choosing the Optimal Number of Clusters

We use two complementary methods:
- **Elbow Method** — inertia (within-cluster sum of squares) vs. k
- **Silhouette Score** — how well-separated and cohesive the clusters are (closer to 1 is better)
""")

code("""inertias = []
silhouettes = []
db_scores = []
k_range = range(2, 11)

for k in k_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(X_scaled)
    inertias.append(km.inertia_)
    silhouettes.append(silhouette_score(X_scaled, labels))
    db_scores.append(davies_bouldin_score(X_scaled, labels))

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

axes[0].plot(list(k_range), inertias, marker='o', color='#2E5266')
axes[0].set_title('Elbow Method')
axes[0].set_xlabel('Number of Clusters (k)')
axes[0].set_ylabel('Inertia (WCSS)')
axes[0].axvline(5, color='#D97B29', linestyle='--', alpha=0.7, label='Chosen k=5')
axes[0].legend()

axes[1].plot(list(k_range), silhouettes, marker='o', color='#B24C4C')
axes[1].set_title('Silhouette Score by k')
axes[1].set_xlabel('Number of Clusters (k)')
axes[1].set_ylabel('Silhouette Score')
axes[1].axvline(5, color='#D97B29', linestyle='--', alpha=0.7, label='Chosen k=5')
axes[1].legend()

plt.tight_layout()
plt.savefig('../images/elbow_silhouette.png', bbox_inches='tight')
plt.show()

for k, inertia, sil, db in zip(k_range, inertias, silhouettes, db_scores):
    print(f"k={k}: inertia={inertia:.1f}  silhouette={sil:.3f}  davies-bouldin={db:.3f}")
""")

md("""**Interpretation:** The elbow flattens noticeably around **k=5**, and silhouette score is locally strong there too, while still keeping segments business-interpretable (too many clusters becomes hard to act on operationally). We proceed with **k=5**.
""")

md("## 7. Fit Final K-Means Model")

code("""kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
df['cluster'] = kmeans.fit_predict(X_scaled)

sil = silhouette_score(X_scaled, df['cluster'])
db = davies_bouldin_score(X_scaled, df['cluster'])
print(f"Final Silhouette Score: {sil:.3f}")
print(f"Final Davies-Bouldin Index: {db:.3f}")
print(f"\\nCluster sizes:\\n{df['cluster'].value_counts().sort_index()}")
""")

md("""## 8. Visualize Segments with PCA

We reduce the standardized feature space to 2 dimensions with PCA purely for visualization (clustering itself was done on the full feature space).
""")

code("""pca = PCA(n_components=2, random_state=42)
pca_result = pca.fit_transform(X_scaled)
df['pca_1'] = pca_result[:, 0]
df['pca_2'] = pca_result[:, 1]

print(f"Explained variance ratio: {pca.explained_variance_ratio_}")
print(f"Total variance captured in 2D: {pca.explained_variance_ratio_.sum():.1%}")

plt.figure(figsize=(9, 7))
scatter = sns.scatterplot(data=df, x='pca_1', y='pca_2', hue='cluster',
                           palette=palette, s=45, alpha=0.75, edgecolor='white', linewidth=0.3)
plt.title('Customer Segments — PCA Projection (2D)')
plt.xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.1%} variance)')
plt.ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.1%} variance)')
plt.legend(title='Segment', loc='best')
plt.tight_layout()
plt.savefig('../images/pca_clusters.png', bbox_inches='tight')
plt.show()
""")

md("""## 9. Cluster Profiling

We now examine each cluster's average behavioral and demographic profile to translate math into marketing-ready personas.
""")

code("""profile_cols = ['age', 'annual_income_inr', 'membership_years', 'purchase_frequency_per_year',
                'avg_order_value_inr', 'total_spend_inr', 'days_since_last_purchase',
                'monthly_app_sessions', 'discount_usage_rate', 'cart_abandonment_rate',
                'product_return_rate', 'satisfaction_score', 'RFM_score']

cluster_profile = df.groupby('cluster')[profile_cols].mean().round(2)
cluster_profile['segment_size'] = df['cluster'].value_counts().sort_index()
cluster_profile['segment_%'] = (cluster_profile['segment_size'] / len(df) * 100).round(1)
cluster_profile
""")

code("""fig, axes = plt.subplots(2, 3, figsize=(17, 9))
plot_cols = ['total_spend_inr', 'purchase_frequency_per_year', 'avg_order_value_inr',
             'days_since_last_purchase', 'monthly_app_sessions', 'discount_usage_rate']
plot_titles = ['Total Spend (INR)', 'Purchase Frequency/yr', 'Avg Order Value (INR)',
               'Days Since Last Purchase', 'Monthly App Sessions', 'Discount Usage Rate']

for ax, col, title in zip(axes.flat, plot_cols, plot_titles):
    sns.barplot(data=df, x='cluster', y=col, ax=ax, palette=palette, errorbar=None)
    ax.set_title(title)
    ax.set_xlabel('Segment')

plt.tight_layout()
plt.savefig('../images/cluster_profiles_bar.png', bbox_inches='tight')
plt.show()
""")

code("""# Radar chart comparing normalized cluster profiles
from math import pi

radar_cols = ['purchase_frequency_per_year', 'avg_order_value_inr', 'total_spend_inr',
              'monthly_app_sessions', 'discount_usage_rate', 'satisfaction_score']
radar_labels = ['Frequency', 'Avg Order Value', 'Total Spend', 'App Engagement', 'Discount Reliance', 'Satisfaction']

radar_data = df.groupby('cluster')[radar_cols].mean()
# recency is 'lower is better' so invert it into a 'recency score' for the radar
radar_data['recency_score'] = 1 / (df.groupby('cluster')['days_since_last_purchase'].mean() + 1)
radar_cols_final = radar_cols + ['recency_score']
radar_labels_final = radar_labels + ['Recency (Activity)']

radar_norm = (radar_data[radar_cols_final] - radar_data[radar_cols_final].min()) / \\
             (radar_data[radar_cols_final].max() - radar_data[radar_cols_final].min())

angles = [n / float(len(radar_cols_final)) * 2 * pi for n in range(len(radar_cols_final))]
angles += angles[:1]

fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))
for i in radar_norm.index:
    values = radar_norm.loc[i].tolist()
    values += values[:1]
    ax.plot(angles, values, linewidth=2, label=f'Segment {i}', color=palette[i % len(palette)])
    ax.fill(angles, values, alpha=0.08, color=palette[i % len(palette)])

ax.set_xticks(angles[:-1])
ax.set_xticklabels(radar_labels_final, size=9)
ax.set_yticklabels([])
plt.title('Normalized Segment Comparison', y=1.08)
plt.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1))
plt.tight_layout()
plt.savefig('../images/radar_comparison.png', bbox_inches='tight')
plt.show()
""")

md("""## 10. Naming the Segments

Based on the cluster profiles above, we assign business-friendly persona names.
""")

code("""# Greedy, rank-based persona assignment: at each step, assign the most distinguishing
# label to whichever *remaining* cluster is the strongest match for it. This avoids
# arbitrary median-split collisions and guarantees each cluster gets a unique persona.
remaining = list(cluster_profile.index)
persona_map = {}

# 1) The cluster with the highest recency (longest since last purchase) is At-Risk
c = cluster_profile.loc[remaining, 'days_since_last_purchase'].idxmax()
persona_map[c] = 'At-Risk / Churn-Prone'
remaining.remove(c)

# 2) Of what's left, highest total spend => Premium Loyalists
c = cluster_profile.loc[remaining, 'total_spend_inr'].idxmax()
persona_map[c] = 'Premium Loyalists'
remaining.remove(c)

# 3) Of what's left, highest discount reliance + frequency => Frequent Bargain Hunters
c = cluster_profile.loc[remaining, 'discount_usage_rate'].idxmax()
persona_map[c] = 'Frequent Bargain Hunters'
remaining.remove(c)

# 4) Of what's left, highest average order value => Premium Browsers
c = cluster_profile.loc[remaining, 'avg_order_value_inr'].idxmax()
persona_map[c] = 'Premium Browsers'
remaining.remove(c)

# 5) Whatever's left => New & Occasional Shoppers
for c in remaining:
    persona_map[c] = 'New & Occasional Shoppers'

df['persona'] = df['cluster'].map(persona_map)
print(persona_map)
df[['customer_id', 'cluster', 'persona']].head(10)
""")

code("""persona_summary = df.groupby('persona')[profile_cols].mean().round(2)
persona_summary['count'] = df['persona'].value_counts()
persona_summary['% of customers'] = (persona_summary['count'] / len(df) * 100).round(1)
persona_summary.sort_values('total_spend_inr', ascending=False)
""")

md("""## 11. Segment Value Contribution

Which segments drive the most revenue vs. headcount? This is the single most useful chart for a marketing/business stakeholder.
""")

code("""revenue_share = df.groupby('persona')['total_spend_inr'].sum().sort_values(ascending=False)
customer_share = df['persona'].value_counts()

fig, axes = plt.subplots(1, 2, figsize=(14, 6))

axes[0].pie(revenue_share, labels=revenue_share.index, autopct='%1.1f%%',
            colors=palette, wedgeprops={'edgecolor': 'white'})
axes[0].set_title('Share of Total Revenue by Segment')

axes[1].pie(customer_share, labels=customer_share.index, autopct='%1.1f%%',
            colors=palette, wedgeprops={'edgecolor': 'white'})
axes[1].set_title('Share of Customer Base by Segment')

plt.tight_layout()
plt.savefig('../images/revenue_vs_headcount.png', bbox_inches='tight')
plt.show()

print("Revenue concentration check:")
for persona in revenue_share.index:
    rev_pct = revenue_share[persona] / revenue_share.sum() * 100
    cust_pct = customer_share[persona] / customer_share.sum() * 100
    print(f"  {persona}: {cust_pct:.1f}% of customers → {rev_pct:.1f}% of revenue (index: {rev_pct/cust_pct:.2f}x)")
""")

md("""## 12. Category Preferences by Segment

Understanding what each segment likes to buy supports targeted product recommendations and campaign creative.
""")

code("""category_by_segment = pd.crosstab(df['persona'], df['preferred_category'], normalize='index') * 100

plt.figure(figsize=(12, 6))
category_by_segment.plot(kind='bar', stacked=True, colormap='tab20', figsize=(12, 6))
plt.title('Preferred Product Category Mix by Segment')
plt.ylabel('% of Segment')
plt.xlabel('')
plt.xticks(rotation=20, ha='right')
plt.legend(bbox_to_anchor=(1.02, 1), loc='upper left', title='Category', fontsize=8)
plt.tight_layout()
plt.savefig('../images/category_by_segment.png', bbox_inches='tight')
plt.show()
""")

md("""## 13. Export Segmented Dataset

We save the final labeled dataset (with cluster ID and persona name) for use in the Power BI / dashboard layer and for downstream marketing systems (CRM, email platform, ad audience uploads).
""")

code("""export_cols = ['customer_id', 'age', 'gender', 'annual_income_inr', 'city_tier',
               'membership_years', 'purchase_frequency_per_year', 'avg_order_value_inr',
               'total_spend_inr', 'days_since_last_purchase', 'monthly_app_sessions',
               'discount_usage_rate', 'cart_abandonment_rate', 'product_return_rate',
               'preferred_category', 'primary_channel', 'satisfaction_score',
               'RFM_score', 'cluster', 'persona']

df[export_cols].to_csv('../data/customers_segmented.csv', index=False)
persona_summary.to_csv('../data/segment_profiles_summary.csv')
print("Exported: customers_segmented.csv, segment_profiles_summary.csv")
df[export_cols].head()
""")

md("""## 14. Business Recommendations Summary

| Segment | Profile | Recommended Strategy |
|---|---|---|
| **Premium Loyalists** | High spend, frequent, recent, low discount reliance | VIP tiering, early access to new drops, referral incentives — protect and reward, avoid over-discounting |
| **Frequent Bargain Hunters** | High frequency, low AOV, heavy discount usage | Bundle offers, loyalty points on full-price items to nudge margin, cross-sell to raise basket size |
| **New & Occasional Shoppers** | Low tenure, low frequency, still exploring | Onboarding journeys, category-discovery nudges, second-purchase incentive within 30 days |
| **At-Risk / Churn-Prone** | Long recency, falling engagement | Win-back campaigns, personalized reactivation discounts, feedback surveys to diagnose drop-off |
| **Premium Browsers** | High income, high AOV, low frequency | Curated/editorial content, high-touch personalization, retarget with premium new arrivals rather than blanket discounts |

**Key insight:** Revenue concentration is not proportional to headcount — a small high-value segment can contribute disproportionately to revenue (see Section 11), which should guide where retention and CRM budget is spent first.

**Next steps for production use:**
- Refresh clustering monthly/quarterly as behavior shifts (avoid static personas)
- A/B test segment-specific campaigns and measure lift over a control group
- Feed `cluster`/`persona` into the CRM and ad platforms as a custom audience field
- Track segment migration over time (e.g. Bargain Hunter → Premium Loyalist) as a loyalty-program KPI
""")

nb = {
    "cells": cells,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "version": "3.11"}
    },
    "nbformat": 4,
    "nbformat_minor": 5
}

with open('/home/claude/customer-segmentation/notebooks/customer_segmentation_analysis.ipynb', 'w') as f:
    json.dump(nb, f, indent=1)

print("Notebook written.")
