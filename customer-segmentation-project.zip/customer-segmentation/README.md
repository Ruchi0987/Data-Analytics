# Customer Segmentation — E-Commerce Behavioral & Demographic Clustering

Unsupervised machine learning project segmenting an e-commerce customer base into actionable personas using K-Means clustering on RFM (Recency, Frequency, Monetary) and behavioral features. Includes a fully executed analysis notebook, an interactive dashboard, and a stakeholder-ready business report.

## 🎯 Project Summary

- **2,500** synthetic e-commerce customers with 16 demographic + behavioral features
- **K-Means clustering** (k=5, chosen via elbow method + silhouette score) → 5 distinct, business-interpretable personas
- **Key finding:** the top segment (17% of customers) drives **61.3%** of total revenue — a 3.6x value index
- Full pipeline: data generation → EDA → RFM feature engineering → preprocessing → clustering → validation → PCA visualization → persona profiling → business recommendations

## 📁 Repository Structure

```
customer-segmentation/
├── data/
│   ├── generate_data.py              # synthetic dataset generator
│   ├── ecommerce_customers.csv       # raw generated dataset (2,500 customers)
│   ├── customers_segmented.csv       # final dataset with cluster/persona labels
│   └── segment_profiles_summary.csv  # aggregated segment-level stats
├── notebooks/
│   └── customer_segmentation_analysis.ipynb   # full, executed analysis (14 sections)
├── dashboard/
│   ├── index.html                    # interactive segmentation dashboard
│   └── segment_data.json             # data feeding the dashboard
├── reports/
│   ├── build_report.js               # docx-js script that generates the report
│   └── Customer_Segmentation_Business_Insights_Report.docx
├── images/                           # exported charts from the notebook
├── resume_bullets.md                 # ATS-optimized resume bullets for this project
├── interview_prep.md                 # likely interview Q&A for this project
├── requirements.txt
└── README.md
```

## 🧠 Methodology

1. **Data generation** — synthetic dataset built from 5 hidden archetypes (premium loyalists, bargain hunters, new/occasional, at-risk, premium browsers) with realistic noise, so clustering has genuine structure to recover.
2. **EDA** — distribution checks, correlation analysis, category/channel breakdowns.
3. **Feature engineering** — RFM scoring (quintile-based) plus engagement and risk signals (app sessions, discount usage, cart abandonment, return rate).
4. **Preprocessing** — one-hot encoding for categoricals, `StandardScaler` for all numeric features.
5. **Model selection** — K-Means run for k=2–10; evaluated via elbow method (inertia), silhouette score, and Davies-Bouldin index. k=5 selected.
6. **Clustering & validation** — final silhouette score: **0.236**; Davies-Bouldin index: **1.649**.
7. **Visualization** — PCA projection to 2D, radar charts for normalized segment comparison, revenue-vs-headcount analysis.
8. **Persona naming** — rank-based, rule-driven assignment of business-friendly names to each cluster (avoids ambiguous median-split heuristics).
9. **Business translation** — segment-specific strategy recommendations (retention, win-back, cross-sell, onboarding).

## 👥 The Five Segments

| Segment | % Customers | % Revenue | Value Index | Strategy |
|---|---|---|---|---|
| **Premium Loyalists** | 17.0% | 61.3% | 3.60x | VIP tiering, protect & reward |
| **Premium Browsers** | 17.8% | 16.0% | 0.90x | Curated content, high-touch personalization |
| **Frequent Bargain Hunters** | 22.8% | 12.9% | 0.56x | Bundles, loyalty points, cross-sell |
| **At-Risk / Churn-Prone** | 19.3% | 6.1% | 0.32x | Win-back campaigns, reactivation offers |
| **New & Occasional Shoppers** | 23.0% | 3.8% | 0.16x | Onboarding journeys, second-purchase incentives |

Full profiles and recommendations are in [`reports/Customer_Segmentation_Business_Insights_Report.docx`](reports/Customer_Segmentation_Business_Insights_Report.docx).

## 🚀 Getting Started

```bash
# Install dependencies
pip install -r requirements.txt

# Regenerate the synthetic dataset (optional — already included)
python data/generate_data.py

# Run the notebook
jupyter notebook notebooks/customer_segmentation_analysis.ipynb

# View the dashboard — just open in a browser
open dashboard/index.html
```

## 📊 Dashboard

`dashboard/index.html` is a standalone, dependency-light HTML dashboard (Chart.js via CDN) that visualizes:
- KPI summary cards
- Revenue concentration vs. customer share
- Segment value index
- Behavioral radar comparison across segments
- Channel preference mix
- Full segment profile table

## 🛠️ Tech Stack

`Python` · `pandas` · `scikit-learn` · `matplotlib` / `seaborn` · `Jupyter` · `HTML/CSS/JS` · `Chart.js`

## 📌 Next Steps (for a production version)

- Refresh segmentation quarterly as behavior drifts
- A/B test segment-specific campaigns against a control group
- Feed `cluster`/`persona` into CRM and ad platforms as a custom audience field
- Track segment migration (e.g. Bargain Hunter → Premium Loyalist) as a loyalty KPI

---

*This project uses a synthetic dataset generated to reflect realistic e-commerce customer behavior patterns, built as a portfolio piece demonstrating an end-to-end customer analytics workflow.*
