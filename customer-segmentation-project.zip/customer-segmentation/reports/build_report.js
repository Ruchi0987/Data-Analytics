const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, AlignmentType, BorderStyle, ImageRun, PageBreak,
  Header, Footer, PageNumber, NumberFormat, LevelFormat, convertInchesToTwip
} = require("docx");

const NAVY = "1A3A53";
const ACCENT = "C97A2E";
const SLATE = "44607A";
const LIGHT = "EEF3F6";
const TEXT = "222222";

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160 },
    border: { bottom: { color: ACCENT, space: 4, style: BorderStyle.SINGLE, size: 10 } },
    children: [new TextRun({ text, bold: true, color: NAVY, size: 30 })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 260, after: 120 },
    children: [new TextRun({ text, bold: true, color: NAVY, size: 24 })],
  });
}
function body(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 160, line: 276 },
    children: [new TextRun({ text, size: 21, color: TEXT, ...opts })],
  });
}
function bullet(text) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { after: 90 },
    children: [new TextRun({ text, size: 21, color: TEXT })],
  });
}
function kicker(text) {
  return new Paragraph({
    spacing: { after: 40 },
    children: [new TextRun({ text: text.toUpperCase(), bold: true, size: 16, color: ACCENT, characterSpacing: 20 })],
  });
}

function statCell(label, value, width) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: { type: ShadingType.CLEAR, fill: LIGHT },
    margins: { top: 160, bottom: 160, left: 160, right: 160 },
    children: [
      new Paragraph({ children: [new TextRun({ text: value, bold: true, size: 30, color: NAVY })] }),
      new Paragraph({ children: [new TextRun({ text: label, size: 16, color: SLATE })] }),
    ],
  });
}

function image(path, width, height) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 200 },
    children: [
      new ImageRun({
        type: "png",
        data: fs.readFileSync(path),
        transformation: { width, height },
      }),
    ],
  });
}

function segTableHeader(cols) {
  return new TableRow({
    tableHeader: true,
    cantSplit: true,
    children: cols.map(c => new TableCell({
      shading: { type: ShadingType.CLEAR, fill: NAVY },
      margins: { top: 100, bottom: 100, left: 100, right: 100 },
      children: [new Paragraph({ children: [new TextRun({ text: c, bold: true, color: "FFFFFF", size: 16 })] })],
    })),
  });
}
function segTableRow(cols, shade) {
  return new TableRow({
    cantSplit: true,
    children: cols.map(c => new TableCell({
      shading: shade ? { type: ShadingType.CLEAR, fill: LIGHT } : undefined,
      margins: { top: 90, bottom: 90, left: 100, right: 100 },
      children: [new Paragraph({ children: [new TextRun({ text: String(c), size: 17, color: TEXT })] })],
    })),
  });
}

const doc = new Document({
  numbering: {
    config: [{
      reference: "bullets",
      levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 360, hanging: 260 } } } }],
    }],
  },
  sections: [{
    properties: {
      page: { size: { width: 12240, height: 15840 }, margin: { top: 1000, bottom: 1000, left: 1100, right: 1100 } },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: "Customer Segmentation — Business Insights Report", size: 14, color: SLATE })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "Page ", size: 14, color: SLATE }),
            new TextRun({ children: [PageNumber.CURRENT], size: 14, color: SLATE }),
          ],
        })],
      }),
    },
    children: [
      // Title block
      new Paragraph({ children: [new TextRun({ text: "E-COMMERCE CUSTOMER ANALYTICS", bold: true, size: 18, color: ACCENT, characterSpacing: 30 })], spacing: { after: 100 } }),
      new Paragraph({ children: [new TextRun({ text: "Customer Segmentation", bold: true, size: 48, color: NAVY })], spacing: { after: 60 } }),
      new Paragraph({ children: [new TextRun({ text: "Business Insights Report", size: 32, color: SLATE })], spacing: { after: 300 } }),
      body("Prepared using K-Means clustering on demographic and behavioral data from a 2,500-customer e-commerce dataset. This report translates the clustering output into five actionable customer personas, revenue-concentration findings, and segment-specific strategy recommendations."),

      new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [new TableRow({ children: [
          statCell("Customers Analyzed", "2,500", 2300),
          statCell("Segments Identified", "5", 2300),
          statCell("Silhouette Score", "0.236", 2300),
          statCell("Top Segment Revenue Share", "61.3%", 2300),
        ]})],
      }),

      new Paragraph({ children: [new PageBreak()] }),

      h1("1. Executive Summary"),
      body("Clustering the customer base on purchase frequency, spend, recency, engagement, and discount behavior surfaces five distinct segments with very different economics. The headline finding: revenue is highly concentrated. Premium Loyalists make up just 17% of customers but generate 61.3% of total revenue \u2014 a 3.6x value index \u2014 while the largest segment by headcount, New & Occasional Shoppers (23% of customers), contributes only 3.8% of revenue."),
      body("This has direct implications for where retention, personalization, and CRM budget should be spent first. It also identifies a meaningful At-Risk segment (19.3% of customers, avg. 96.5 days since last purchase) that represents a concrete win-back opportunity rather than a lost cause."),

      h1("2. Methodology"),
      h2("2.1 Data"),
      body("A synthetic dataset of 2,500 customers was constructed with realistic demographic attributes (age, gender, income, city tier) and behavioral metrics (purchase frequency, average order value, recency, app engagement, discount usage, cart abandonment, return rate, satisfaction score)."),
      h2("2.2 Feature Engineering"),
      body("Behavioral features were framed using the RFM (Recency, Frequency, Monetary) marketing framework, extended with engagement and risk signals. All numeric features were standardized (zero mean, unit variance); categorical features (city tier, primary channel) were one-hot encoded."),
      h2("2.3 Clustering"),
      body("K-Means was run for k = 2 through 10, evaluated via the elbow method (inertia) and silhouette score. k = 5 was selected as the point where the elbow flattens while keeping segments operationally interpretable for a marketing team. The final model achieved a silhouette score of 0.236 and a Davies-Bouldin index of 1.649."),

      image("../images/elbow_silhouette.png", 5800000 / 9525, 2000000 / 9525),

      new Paragraph({ children: [new PageBreak()] }),

      h1("3. Segment Overview"),
      new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [
          segTableHeader(["Segment", "% Customers", "% Revenue", "Avg. Spend (\u20B9)", "Value Index"]),
          segTableRow(["Premium Loyalists", "17.0%", "61.3%", "1,04,661", "3.60x"], true),
          segTableRow(["Premium Browsers", "17.8%", "16.0%", "26,029", "0.90x"], false),
          segTableRow(["Frequent Bargain Hunters", "22.8%", "12.9%", "16,417", "0.56x"], true),
          segTableRow(["At-Risk / Churn-Prone", "19.3%", "6.1%", "9,162", "0.32x"], false),
          segTableRow(["New & Occasional Shoppers", "23.0%", "3.8%", "4,753", "0.16x"], true),
        ],
      }),

      new Paragraph({ children: [new PageBreak()] }),

      image("../images/pca_clusters.png", 5800000 / 9525, 4500000 / 9525),
      image("../images/revenue_vs_headcount.png", 5800000 / 9525, 2800000 / 9525),

      new Paragraph({ children: [new PageBreak()] }),

      h1("4. Segment Profiles & Recommendations"),

      h2("4.1 Premium Loyalists \u2014 17.0% of customers, 61.3% of revenue"),
      body("High spend, high frequency (27.7 purchases/yr), very recent activity (avg. 6 days), low discount reliance (12%), highest satisfaction (3.83/5)."),
      bullet("Protect this segment aggressively \u2014 it is the single most valuable group by a wide margin."),
      bullet("Offer VIP tiering, early access to new arrivals, and referral incentives rather than blanket discounts, which would erode margin unnecessarily."),
      bullet("Monitor for early churn signals (rising recency, falling sessions) since losing even a few of these customers has outsized revenue impact."),

      h2("4.2 Premium Browsers \u2014 17.8% of customers, 16.0% of revenue"),
      body("Highest income and average order value (\u20B95,222) but low purchase frequency (5.0/yr); older average age (40.7); lowest discount usage."),
      bullet("Use curated, editorial-style content and high-touch personalization rather than volume discounting."),
      bullet("Retarget with premium new arrivals and limited releases to convert browsing into purchase."),
      bullet("Investigate the moderate satisfaction score (3.17) \u2014 likely tied to purchase friction rather than price sensitivity."),

      h2("4.3 Frequent Bargain Hunters \u2014 22.8% of customers, 12.9% of revenue"),
      body("Very high frequency (18.9/yr) and app engagement, but low average order value (\u20B9865) and heavy discount reliance (69%)."),
      bullet("Introduce bundle offers and loyalty points that reward full-price purchases to gradually lift basket size."),
      bullet("Cross-sell complementary categories to increase order value without relying solely on markdowns."),
      bullet("Treat as a volume-and-engagement asset, not a margin driver \u2014 optimize for lifetime value, not per-order profit."),

      h2("4.4 At-Risk / Churn-Prone \u2014 19.3% of customers, 6.1% of revenue"),
      body("Longest recency (avg. 96.5 days since last purchase), lowest app engagement (3.0 sessions/month), below-average satisfaction (3.01)."),
      bullet("Launch a win-back campaign with personalized reactivation offers, prioritizing customers with previously high lifetime value."),
      bullet("Deploy a short feedback survey to diagnose the specific reason for disengagement (price, assortment, service, competitor switch)."),
      bullet("Set a reactivation-rate KPI and track it as a leading indicator, since this segment overlaps with previously higher-value customers who are drifting away."),

      h2("4.5 New & Occasional Shoppers \u2014 23.0% of customers, 3.8% of revenue"),
      body("Lowest tenure (0.56 yrs), lowest frequency (3.4/yr) and spend, youngest average age (26.2) \u2014 still in an exploratory phase with the brand."),
      bullet("Build a structured onboarding journey with category-discovery nudges in the first 30\u201360 days."),
      bullet("Offer a second-purchase incentive to move customers past the highest-risk early drop-off window."),
      bullet("Track segment migration over time \u2014 the goal is graduation into Bargain Hunter or Loyalist, not permanent residency here."),

      new Paragraph({ children: [new PageBreak()] }),

      h1("5. Key Takeaways"),
      bullet("Revenue is concentrated, not evenly distributed \u2014 a 3.6x value index for the top segment means retention spend should be prioritized there first."),
      bullet("The At-Risk segment is a reactivation opportunity, not a lost cause: these were previously active, higher-frequency customers."),
      bullet("Discount-driven volume (Bargain Hunters) and low-frequency premium spend (Premium Browsers) require opposite playbooks \u2014 one needs margin protection, the other needs frequency-building."),
      bullet("Segments should be refreshed quarterly, since behavior drifts and a customer's segment membership is not permanent."),

      h1("6. Next Steps"),
      bullet("Feed the cluster/persona label into the CRM and ad platforms as a custom audience field."),
      bullet("A/B test segment-specific campaigns against a control group and measure incremental lift, not just response rate."),
      bullet("Track segment migration (e.g., Bargain Hunter \u2192 Premium Loyalist) as a formal loyalty-program KPI."),
      bullet("Extend the feature set with product-level affinity data if/when available, to support segment-specific merchandising."),
    ],
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/customer-segmentation/reports/Customer_Segmentation_Business_Insights_Report.docx", buf);
  console.log("Report written.");
});
